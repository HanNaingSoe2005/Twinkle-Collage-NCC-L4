﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FitnessApplication
{
    public partial class HNSfrmFitnessApplicationStart : Form
    {
        public HNSfrmFitnessApplicationStart()
        {
            InitializeComponent();
        }

       

        private void Close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Loginclick_Click(object sender, EventArgs e)
        {
            HNSfrmLogin hnsfrmLogin = new HNSfrmLogin();
            hnsfrmLogin.ShowDialog();
        }

        private void Registerclick_Click(object sender, EventArgs e)
        {
            HNSfrmRegister hnsfrmRegister = new HNSfrmRegister();
            hnsfrmRegister.ShowDialog();
        }
    }
}
