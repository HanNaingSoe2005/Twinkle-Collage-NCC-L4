﻿namespace FitnessApplication
{
    partial class HNSFitnessActivity
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.HnslUsername = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lblCurrentCal = new System.Windows.Forms.Label();
            this.Calculateclick = new System.Windows.Forms.Button();
            this.HnstxtTime = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.HnstxtWeight = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.HnstxtMET = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.rdoBasketball = new System.Windows.Forms.RadioButton();
            this.rdoBadminton = new System.Windows.Forms.RadioButton();
            this.HnsActivityGpBox = new System.Windows.Forms.GroupBox();
            this.rdoTableTennis = new System.Windows.Forms.RadioButton();
            this.rdoWalking = new System.Windows.Forms.RadioButton();
            this.rdoSwimming = new System.Windows.Forms.RadioButton();
            this.rdoRunning = new System.Windows.Forms.RadioButton();
            this.HnsRemaining = new System.Windows.Forms.Label();
            this.HnslTotalCal = new System.Windows.Forms.Label();
            this.Close = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.HnsActivityGpBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // HnslUsername
            // 
            this.HnslUsername.AutoSize = true;
            this.HnslUsername.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.HnslUsername.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HnslUsername.Location = new System.Drawing.Point(714, 37);
            this.HnslUsername.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.HnslUsername.Name = "HnslUsername";
            this.HnslUsername.Size = new System.Drawing.Size(131, 23);
            this.HnslUsername.TabIndex = 0;
            this.HnslUsername.Text = "Welcome user =";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(54, 78);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(449, 222);
            this.dataGridView1.TabIndex = 27;
            // 
            // lblCurrentCal
            // 
            this.lblCurrentCal.AutoSize = true;
            this.lblCurrentCal.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lblCurrentCal.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentCal.Location = new System.Drawing.Point(715, 465);
            this.lblCurrentCal.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCurrentCal.Name = "lblCurrentCal";
            this.lblCurrentCal.Size = new System.Drawing.Size(123, 19);
            this.lblCurrentCal.TabIndex = 26;
            this.lblCurrentCal.Text = "Calorie Burnt =";
            // 
            // Calculateclick
            // 
            this.Calculateclick.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.Calculateclick.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Calculateclick.Location = new System.Drawing.Point(912, 460);
            this.Calculateclick.Margin = new System.Windows.Forms.Padding(2);
            this.Calculateclick.Name = "Calculateclick";
            this.Calculateclick.Size = new System.Drawing.Size(114, 31);
            this.Calculateclick.TabIndex = 25;
            this.Calculateclick.Text = "Calculate";
            this.Calculateclick.UseVisualStyleBackColor = false;
            this.Calculateclick.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // HnstxtTime
            // 
            this.HnstxtTime.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.HnstxtTime.Location = new System.Drawing.Point(865, 397);
            this.HnstxtTime.Margin = new System.Windows.Forms.Padding(2);
            this.HnstxtTime.Name = "HnstxtTime";
            this.HnstxtTime.Size = new System.Drawing.Size(136, 20);
            this.HnstxtTime.TabIndex = 24;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(770, 397);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 20);
            this.label3.TabIndex = 23;
            this.label3.Text = "Time (min)";
            // 
            // HnstxtWeight
            // 
            this.HnstxtWeight.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.HnstxtWeight.Location = new System.Drawing.Point(865, 344);
            this.HnstxtWeight.Margin = new System.Windows.Forms.Padding(2);
            this.HnstxtWeight.Name = "HnstxtWeight";
            this.HnstxtWeight.Size = new System.Drawing.Size(136, 20);
            this.HnstxtWeight.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(767, 345);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 20);
            this.label2.TabIndex = 21;
            this.label2.Text = "Weight (kg)";
            // 
            // HnstxtMET
            // 
            this.HnstxtMET.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.HnstxtMET.Location = new System.Drawing.Point(865, 305);
            this.HnstxtMET.Margin = new System.Windows.Forms.Padding(2);
            this.HnstxtMET.Name = "HnstxtMET";
            this.HnstxtMET.Size = new System.Drawing.Size(136, 20);
            this.HnstxtMET.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(767, 303);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 20);
            this.label1.TabIndex = 19;
            this.label1.Text = "MET value ";
            // 
            // rdoBasketball
            // 
            this.rdoBasketball.AutoSize = true;
            this.rdoBasketball.Location = new System.Drawing.Point(268, 71);
            this.rdoBasketball.Margin = new System.Windows.Forms.Padding(2);
            this.rdoBasketball.Name = "rdoBasketball";
            this.rdoBasketball.Size = new System.Drawing.Size(74, 17);
            this.rdoBasketball.TabIndex = 5;
            this.rdoBasketball.TabStop = true;
            this.rdoBasketball.Text = "Basketball\r\n";
            this.rdoBasketball.UseVisualStyleBackColor = true;
            // 
            // rdoBadminton
            // 
            this.rdoBadminton.AutoSize = true;
            this.rdoBadminton.Location = new System.Drawing.Point(161, 71);
            this.rdoBadminton.Margin = new System.Windows.Forms.Padding(2);
            this.rdoBadminton.Name = "rdoBadminton";
            this.rdoBadminton.Size = new System.Drawing.Size(75, 17);
            this.rdoBadminton.TabIndex = 4;
            this.rdoBadminton.TabStop = true;
            this.rdoBadminton.Text = "Badminton\r\n";
            this.rdoBadminton.UseVisualStyleBackColor = true;
            // 
            // HnsActivityGpBox
            // 
            this.HnsActivityGpBox.Controls.Add(this.rdoBasketball);
            this.HnsActivityGpBox.Controls.Add(this.rdoBadminton);
            this.HnsActivityGpBox.Controls.Add(this.rdoTableTennis);
            this.HnsActivityGpBox.Controls.Add(this.rdoWalking);
            this.HnsActivityGpBox.Controls.Add(this.rdoSwimming);
            this.HnsActivityGpBox.Controls.Add(this.rdoRunning);
            this.HnsActivityGpBox.Location = new System.Drawing.Point(54, 344);
            this.HnsActivityGpBox.Margin = new System.Windows.Forms.Padding(2);
            this.HnsActivityGpBox.Name = "HnsActivityGpBox";
            this.HnsActivityGpBox.Padding = new System.Windows.Forms.Padding(2);
            this.HnsActivityGpBox.Size = new System.Drawing.Size(385, 131);
            this.HnsActivityGpBox.TabIndex = 18;
            this.HnsActivityGpBox.TabStop = false;
            this.HnsActivityGpBox.Text = "Choose an activity";
            // 
            // rdoTableTennis
            // 
            this.rdoTableTennis.AutoSize = true;
            this.rdoTableTennis.Location = new System.Drawing.Point(268, 36);
            this.rdoTableTennis.Margin = new System.Windows.Forms.Padding(2);
            this.rdoTableTennis.Name = "rdoTableTennis";
            this.rdoTableTennis.Size = new System.Drawing.Size(87, 17);
            this.rdoTableTennis.TabIndex = 3;
            this.rdoTableTennis.TabStop = true;
            this.rdoTableTennis.Text = "Table Tennis\r\n";
            this.rdoTableTennis.UseVisualStyleBackColor = true;
            // 
            // rdoWalking
            // 
            this.rdoWalking.AutoSize = true;
            this.rdoWalking.Location = new System.Drawing.Point(161, 36);
            this.rdoWalking.Margin = new System.Windows.Forms.Padding(2);
            this.rdoWalking.Name = "rdoWalking";
            this.rdoWalking.Size = new System.Drawing.Size(64, 17);
            this.rdoWalking.TabIndex = 2;
            this.rdoWalking.TabStop = true;
            this.rdoWalking.Text = "Walking";
            this.rdoWalking.UseVisualStyleBackColor = true;
            // 
            // rdoSwimming
            // 
            this.rdoSwimming.AutoSize = true;
            this.rdoSwimming.Location = new System.Drawing.Point(21, 71);
            this.rdoSwimming.Margin = new System.Windows.Forms.Padding(2);
            this.rdoSwimming.Name = "rdoSwimming";
            this.rdoSwimming.Size = new System.Drawing.Size(72, 17);
            this.rdoSwimming.TabIndex = 1;
            this.rdoSwimming.TabStop = true;
            this.rdoSwimming.Text = "Swimming";
            this.rdoSwimming.UseVisualStyleBackColor = true;
            // 
            // rdoRunning
            // 
            this.rdoRunning.AutoSize = true;
            this.rdoRunning.Location = new System.Drawing.Point(21, 36);
            this.rdoRunning.Margin = new System.Windows.Forms.Padding(2);
            this.rdoRunning.Name = "rdoRunning";
            this.rdoRunning.Size = new System.Drawing.Size(65, 17);
            this.rdoRunning.TabIndex = 0;
            this.rdoRunning.TabStop = true;
            this.rdoRunning.Text = "Running";
            this.rdoRunning.UseVisualStyleBackColor = true;
            // 
            // HnsRemaining
            // 
            this.HnsRemaining.AutoSize = true;
            this.HnsRemaining.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.HnsRemaining.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HnsRemaining.Location = new System.Drawing.Point(688, 128);
            this.HnsRemaining.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.HnsRemaining.Name = "HnsRemaining";
            this.HnsRemaining.Size = new System.Drawing.Size(157, 23);
            this.HnsRemaining.TabIndex = 17;
            this.HnsRemaining.Text = "Remaining Calorie=";
            // 
            // HnslTotalCal
            // 
            this.HnslTotalCal.AutoSize = true;
            this.HnslTotalCal.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.HnslTotalCal.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HnslTotalCal.Location = new System.Drawing.Point(714, 78);
            this.HnslTotalCal.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.HnslTotalCal.Name = "HnslTotalCal";
            this.HnslTotalCal.Size = new System.Drawing.Size(131, 23);
            this.HnslTotalCal.TabIndex = 16;
            this.HnslTotalCal.Text = "Total Cal Burnt=";
            // 
            // Close
            // 
            this.Close.AutoSize = true;
            this.Close.BackColor = System.Drawing.Color.MidnightBlue;
            this.Close.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Close.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Close.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Close.Location = new System.Drawing.Point(997, 9);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(29, 31);
            this.Close.TabIndex = 28;
            this.Close.Text = "X";
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClose.Location = new System.Drawing.Point(583, 460);
            this.btnClose.Margin = new System.Windows.Forms.Padding(2);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(114, 31);
            this.btnClose.TabIndex = 29;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // HNSFitnessActivity
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = global::FitnessApplication.Properties.Resources.istockphoto_525689305_612x612;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1037, 502);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblCurrentCal);
            this.Controls.Add(this.Calculateclick);
            this.Controls.Add(this.HnstxtTime);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.HnstxtWeight);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.HnstxtMET);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.HnsActivityGpBox);
            this.Controls.Add(this.HnsRemaining);
            this.Controls.Add(this.HnslTotalCal);
            this.Controls.Add(this.HnslUsername);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "HNSFitnessActivity";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Fitness Activity";
            this.Load += new System.EventHandler(this.frmFitnessApplicationActivity_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.HnsActivityGpBox.ResumeLayout(false);
            this.HnsActivityGpBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label HnslUsername;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lblCurrentCal;
        private System.Windows.Forms.Button Calculateclick;
        private System.Windows.Forms.TextBox HnstxtTime;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox HnstxtWeight;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox HnstxtMET;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rdoBasketball;
        private System.Windows.Forms.RadioButton rdoBadminton;
        private System.Windows.Forms.GroupBox HnsActivityGpBox;
        private System.Windows.Forms.RadioButton rdoTableTennis;
        private System.Windows.Forms.RadioButton rdoWalking;
        private System.Windows.Forms.RadioButton rdoSwimming;
        private System.Windows.Forms.RadioButton rdoRunning;
        private System.Windows.Forms.Label HnsRemaining;
        private System.Windows.Forms.Label HnslTotalCal;
        private System.Windows.Forms.Label Close;
        private System.Windows.Forms.Button btnClose;
    }
}