﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Windows.Forms;
using System.Data;

namespace FitnessApplication
{
    public class ClassFitnessUser
    {
        OleDbCommand hnscmd;
        OleDbDataReader hnsreader;
        OleDbConnection hnsconn;
        String constr;
       ////Create AND Login database
       // public string Username;
       // public string Password;

       //Register
       public int userid;
       public string Firstusername;
       public string Lastusername;
       public string password;
       public string phone;
       public string email;
       public float targetCalo;

      public ClassFitnessUser() //constructor 
        {
            constr = "Provider=Microsoft.ACE.OLEDB.12.0;" +
             "Data Source=" + Application.StartupPath + @"\FitnessDB.mdb";
            hnsconn = new OleDbConnection();
            hnsconn.ConnectionString = constr;

        }

        private int getMaxUserId() //Data type method
        {
            hnscmd = new OleDbCommand();
            hnscmd.Connection = hnsconn;

            int id = 0;
            string query = "Select MAX(uid) from [User]";
            hnscmd.CommandText = query;
            try
            {
                hnsconn.Open();
                if (hnscmd.ExecuteScalar() != DBNull.Value)
                    id = Convert.ToInt32(hnscmd.ExecuteScalar().ToString());
                else id = 0;

                return id + 1;
            }
            catch (OleDbException oex) { throw oex; }
            finally
            {
                hnsconn.Close();
            }
        }

        public void CreateAccount(ClassFitnessUser u)  //carry input from client
        {

            int id = getMaxUserId();   //Id form Database MA
            string query = "INSERT INTO [User] VALUES " + "('" + id + "','" + u.Firstusername + "','"+ u.Lastusername +"','" + u.password + "','" +u.phone+"','"+ u.email + "','" + u.targetCalo + "')";
           
            hnsconn.Open();
            hnscmd = new OleDbCommand(query, hnsconn);

            hnscmd.ExecuteScalar();
            hnsconn.Close();

        }

        public int checkExistingUser(string uname) // (Data type) method
        {
            hnscmd = new OleDbCommand();
            hnscmd.Connection = hnsconn;
            OleDbDataReader reader;
            int id = 0;
            string query = "Select uid  from [User] where Firstusername='" + uname + "'";
            hnscmd.CommandText = query;
            hnsconn.Open();
            reader = hnscmd.ExecuteReader();

            try
            {

                if (reader.Read())
                    id = 1;
                else id = 0;

                reader.Close();
                return id;
            }


            catch (OleDbException oex) { throw oex; }
            finally
            {
                hnsconn.Close();
            }
        }
        // login function

        public int btnLogin(string uname, string password) // (Data type) method
        {
            hnscmd = new OleDbCommand();
            hnscmd.Connection = hnsconn;
            OleDbDataReader reader;
            int id = 0;
            string query = "Select uid  from [User] where Firstusername='" + uname + "' AND password='" + password + "'";
            hnscmd.CommandText = query;
            hnsconn.Open();
            reader = hnscmd.ExecuteReader();

            try
            {
                if (reader.Read())
                    id = int.Parse(reader.GetValue(0).ToString());
                else id = 0;

                reader.Close();
                return id;
            }


            catch (OleDbException oex) { throw oex; }
            finally
            {
                hnsconn.Close();
            }
        }

       
        //end of the class
    }
}
