﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace FitnessApplication
{
    public partial class HNSfrmLogin : Form
    {
        public HNSfrmLogin()
        {
            InitializeComponent();
        }

    

        private void btnLogin_Click(object sender, EventArgs e)
        {
            //Absence check
            if (UserName.Text == "" || Password.Text == "")
            {
                MessageBox.Show("Please enter all fields");
                return;
            }




            ClassFitnessUser user = new ClassFitnessUser();
            int uid = user.btnLogin(UserName.Text, Password.Text);
            if (uid != 0)
            {
                HNSFitnessActivity acform = new HNSFitnessActivity(uid, UserName.Text);
                acform.ShowDialog();
            }
            else
            {
                MessageBox.Show("Login failure");
            }
        }

        private void Close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Password_TextChanged(object sender, EventArgs e)
        {

        }

        private void ShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (ShowPassword.Checked)
            {
                Password.UseSystemPasswordChar = false;
            }
            else
            {
                Password.UseSystemPasswordChar = true;
            }
        }
    }
}
