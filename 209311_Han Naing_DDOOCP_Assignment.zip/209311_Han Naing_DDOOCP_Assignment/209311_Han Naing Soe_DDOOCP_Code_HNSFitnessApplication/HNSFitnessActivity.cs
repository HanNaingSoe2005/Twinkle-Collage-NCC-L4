﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FitnessApplication
{
    public partial class HNSFitnessActivity : Form
    {
        int uid;
        string uname;
        public HNSFitnessActivity(int userid, string username)
        {
            InitializeComponent();
            uid = userid;
            uname = username;
        }

        private void frmFitnessApplicationActivity_Load(object sender, EventArgs e)
        {
            HnslUsername.Text = "Welcome user=" + uname;
            DataBind();

        }
        private void DataBind()
        {

            HnslUsername.Text = "Welcome userid=" + uid.ToString();
            ClassHnsActivity ac = new ClassHnsActivity();
            float tcal = ac.getTotalCal(uid);
            HnslTotalCal.Text = "Total Calorie=" + tcal.ToString();

            float target = ac.checkTargetCal(uid);
            float remain = target - tcal;
            if (remain <= 0 || remain == 0.0)
            {
                MessageBox.Show("Your target has beent met.");


                HnsRemaining.Text = "0";

            }
            else
                HnsRemaining.Text = "Remaining Calorie= " + remain.ToString();

            dataGridView1.DataSource = ac.getTable(uid);
            dataGridView1.DataMember = "ActivityMetric";

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            if (rdoWalking.Checked)
            {
                ClassWalking w = new ClassWalking();
                w.metric1 = float.Parse(HnstxtMET.Text);
                w.metric2 = float.Parse(HnstxtWeight.Text);
                w.metric3 = float.Parse(HnstxtTime.Text);

                float scal = w.WalkingActivity(uid, w.metric1, w.metric2, w.metric3);
                w.insertCalvalue(uid, 2, w.metric1, w.metric2, w.metric3, scal);
                lblCurrentCal.Text = "Current Calorie=" + scal.ToString();


            }
            else if (rdoSwimming.Checked)
            {
                ClassSwimming s = new ClassSwimming();
                s.metric1 = float.Parse(HnstxtMET.Text);
                s.metric2 = float.Parse(HnstxtWeight.Text);
                s.metric3 = float.Parse(HnstxtTime.Text);

                float scal = s.SwimmingActivity(uid, s.metric1, s.metric2, s.metric3);
                s.insertCalvalue(uid, 2, s.metric1, s.metric2, s.metric3, scal);
                lblCurrentCal.Text = "Current Calorie=" + scal.ToString();

            }
            else if (rdoTableTennis.Checked)
            {
                ClassTableTennis s = new ClassTableTennis();
                s.metric1 = float.Parse(HnstxtMET.Text);
                s.metric2 = float.Parse(HnstxtWeight.Text);
                s.metric3 = float.Parse(HnstxtTime.Text);

                float scal = s.Table_Tennis_Activity(uid, s.metric1, s.metric2, s.metric3);
                s.insertCalvalue(uid, 2, s.metric1, s.metric2, s.metric3, scal);
                lblCurrentCal.Text = "Current Calorie=" + scal.ToString();

            }
            else if (rdoBadminton.Checked)
            {
                ClassBadminton s = new ClassBadminton();
                s.metric1 = float.Parse(HnstxtMET.Text);
                s.metric2 = float.Parse(HnstxtWeight.Text);
                s.metric3 = float.Parse(HnstxtTime.Text);

                float scal = s.BadmintonActivity(uid, s.metric1, s.metric2, s.metric3);
                s.insertCalvalue(uid, 2, s.metric1, s.metric2, s.metric3, scal);
                lblCurrentCal.Text = "Current Calorie=" + scal.ToString();


                DataBind();


            }
            else if (rdoBasketball.Checked)
            {
                ClassBasketball s = new ClassBasketball();
                s.metric1 = float.Parse(HnstxtMET.Text);
                s.metric2 = float.Parse(HnstxtWeight.Text);
                s.metric3 = float.Parse(HnstxtTime.Text);

                float scal = s.BasketballActivity(uid, s.metric1, s.metric2, s.metric3);
                s.insertCalvalue(uid, 2, s.metric1, s.metric2, s.metric3, scal);
                lblCurrentCal.Text = "Current Calorie=" + scal.ToString();


                DataBind();


            }
            else if (rdoRunning.Checked)
            {
                ClassRunnig s = new ClassRunnig();
                s.metric1 = float.Parse(HnstxtMET.Text);
                s.metric2 = float.Parse(HnstxtWeight.Text);
                s.metric3 = float.Parse(HnstxtTime.Text);

                float scal = s.RunningActivity(uid, s.metric1, s.metric2, s.metric3);
                s.insertCalvalue(uid, 2, s.metric1, s.metric2, s.metric3, scal);
                lblCurrentCal.Text = "Current Calorie=" + scal.ToString();


                DataBind();


            }

        }
            private void btnClose_Click(object sender, EventArgs e)
            {
               this.Close();
            }


          


     }
 }


