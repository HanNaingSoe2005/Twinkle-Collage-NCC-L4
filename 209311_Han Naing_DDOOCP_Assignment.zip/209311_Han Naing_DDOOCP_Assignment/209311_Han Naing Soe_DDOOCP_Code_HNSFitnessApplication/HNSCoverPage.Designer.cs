﻿namespace FitnessApplication
{
    partial class HNSfrmFitnessApplicationStart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Loginclick = new System.Windows.Forms.Button();
            this.Registerclick = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Close = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Loginclick
            // 
            this.Loginclick.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Loginclick.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Loginclick.ForeColor = System.Drawing.SystemColors.Window;
            this.Loginclick.Location = new System.Drawing.Point(571, 228);
            this.Loginclick.Margin = new System.Windows.Forms.Padding(2);
            this.Loginclick.Name = "Loginclick";
            this.Loginclick.Size = new System.Drawing.Size(92, 36);
            this.Loginclick.TabIndex = 1;
            this.Loginclick.Text = "Login";
            this.Loginclick.UseVisualStyleBackColor = false;
            this.Loginclick.Click += new System.EventHandler(this.Loginclick_Click);
            // 
            // Registerclick
            // 
            this.Registerclick.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Registerclick.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Registerclick.ForeColor = System.Drawing.SystemColors.Window;
            this.Registerclick.Location = new System.Drawing.Point(70, 228);
            this.Registerclick.Margin = new System.Windows.Forms.Padding(2);
            this.Registerclick.Name = "Registerclick";
            this.Registerclick.Size = new System.Drawing.Size(91, 34);
            this.Registerclick.TabIndex = 0;
            this.Registerclick.Text = "Register";
            this.Registerclick.UseVisualStyleBackColor = false;
            this.Registerclick.Click += new System.EventHandler(this.Registerclick_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label1.Location = new System.Drawing.Point(161, 121);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(433, 31);
            this.label1.TabIndex = 2;
            this.label1.Text = "🏸<Your Choose> || <Your Liftstyle>🎾\r\n";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(247, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(262, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "🎈Welcome to HNS Fitness 🎈";
            // 
            // Close
            // 
            this.Close.AutoSize = true;
            this.Close.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Close.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Close.Location = new System.Drawing.Point(669, 9);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(29, 31);
            this.Close.TabIndex = 5;
            this.Close.Text = "X";
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // HNSfrmFitnessApplicationStart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::FitnessApplication.Properties.Resources.fitness_seamless_pattern_with_blue_icons_vector_18766266;
            this.ClientSize = new System.Drawing.Size(710, 297);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Loginclick);
            this.Controls.Add(this.Registerclick);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "HNSfrmFitnessApplicationStart";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Start Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Loginclick;
        private System.Windows.Forms.Button Registerclick;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Close;
    }
}

