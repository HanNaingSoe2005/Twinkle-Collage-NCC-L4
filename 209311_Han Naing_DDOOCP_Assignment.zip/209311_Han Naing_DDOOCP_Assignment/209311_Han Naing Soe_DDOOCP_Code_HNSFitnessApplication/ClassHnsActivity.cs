﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FitnessApplication
{
    public class ClassHnsActivity
    {
        OleDbCommand hnscmd;
        OleDbDataReader hnsreader;
        OleDbConnection hnsconn;
        String hnsconstr;

        public float metric1;
        public float metric2;
        public float metric3;
        public float totalCalo = 0.0f;
        public float targetCalo = 0.0f;


        public ClassHnsActivity() {
            hnsconstr = "Provider=Microsoft.ACE.OLEDB.12.0;" +
                            "Data Source=" + Application.StartupPath + @"\FitnessDB.mdb";
            hnsconn = new OleDbConnection();
            hnsconn.ConnectionString = hnsconstr;
        }

        public void insertCalvalue(int uid, int aid, float m1, float m2, float m3, float curcal)
        {
            int mid = getMaxActivityId();


            string query = "INSERT INTO [Metric] VALUES (" + mid + "," + uid + "," + aid + "," + m1 + "," + m2 + "," + m3 + "," + curcal + ")";

            hnsconn.Open();
            hnscmd = new OleDbCommand(query, hnsconn);

            hnscmd.ExecuteScalar();
            hnsconn.Close();
        }

        private int getMaxActivityId() //type (Data type) function 
        {
            hnscmd = new OleDbCommand();
            hnscmd.Connection = hnsconn;

            int id = 0;
            string query = "Select MAX(mid) from [Metric]";
            hnscmd.CommandText = query;
            try
            {
                hnsconn.Open();
                if (hnscmd.ExecuteScalar() != DBNull.Value)
                    id = Convert.ToInt32(hnscmd.ExecuteScalar().ToString());
                else id = 0;

                return id + 1;
            }
            catch (OleDbException oex) { throw oex; }
            finally
            {
                hnsconn.Close();
            }
        }
        public float checkTargetCal(int uid)
        {
            hnscmd = new OleDbCommand();
            hnscmd.Connection = hnsconn;
            OleDbDataReader reader;
            int id = 0;
            string query = "Select targetCal from [User] where uid=" + uid;
            hnscmd.CommandText = query;
            hnsconn.Open();
            reader = hnscmd.ExecuteReader();

            try
            {
                if (reader.Read())
                    targetCalo = float.Parse(reader.GetValue(0).ToString());


                reader.Close();
                return targetCalo;
            }


            catch (OleDbException oex) { throw oex; }
            finally
            {
                hnsconn.Close();
            }


        }
        public float getTotalCal(int uid)
        {
            hnscmd = new OleDbCommand();
            hnscmd.Connection = hnsconn;
            OleDbDataReader reader;
            float totalCal = 0.0f;
            string query = "Select Sum(cal) from [Metric] where uid=" + uid;
            hnscmd.CommandText = query;
            hnsconn.Open();
            reader = hnscmd.ExecuteReader();
            try
            {
                if (reader.Read())
                {
                    string str = reader.GetValue(0).ToString();
                    if (str == "") return 0f;
                    else
                    {
                        totalCal = float.Parse(str);
                    }
                }

                reader.Close();
                return totalCal;
            }

            catch (OleDbException oex) { throw oex; }
            finally
            {
                hnsconn.Close();
            }
        }
        public DataSet getTable(int uid)
        {
            string sql = "SELECT * FROM [Metric] where uid=" + uid;
            OleDbConnection connection = new OleDbConnection(hnsconstr);
            OleDbDataAdapter dataadapter = new OleDbDataAdapter(sql, connection);
            DataSet ds = new DataSet();
            connection.Open();
            dataadapter.Fill(ds, "ActivityMetric");
            connection.Close();
            return ds;

        }
    }
}
