﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Xml.Linq;
using System.Text.RegularExpressions;

namespace FitnessApplication
{
    public partial class HNSfrmRegister : Form
    {
      

        public HNSfrmRegister()
        {
            InitializeComponent();
           

        }

       
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            //Absence check
            if (txtFirstName.Text == "" && txtLastName.Text =="" || Password.Text == "" || PhNobtn.Text=="" ||txtEmail.Text == "" || txtCalGoal.Text == "")
            {
                MessageBox.Show("Enter all the fields");
                return;
            }

            // password criteria and range check
            if (!Regex.IsMatch(Password.Text, "[A-Z]") || !Regex.IsMatch(Password.Text, "[a-z]") || Password.Text.Length != 12)
            {
                MessageBox.Show("Try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
          

            ClassFitnessUser hnsUser = new ClassFitnessUser();
            hnsUser.Firstusername =txtFirstName.Text;
            hnsUser.Lastusername = txtLastName.Text;
            hnsUser.password =Password.Text;
            hnsUser.phone    =PhNobtn.Text;
            hnsUser.email =txtEmail.Text;
            hnsUser.targetCalo=float.Parse(txtCalGoal.Text);

            //exisiting user check
            if (hnsUser.checkExistingUser(hnsUser.Firstusername ) == 1)
            {
                MessageBox.Show("User already exist.");
                return;
            }
            else
            {
                hnsUser.CreateAccount(hnsUser);
                MessageBox.Show("Registration successful ");
            }

             HNSFitnessActivity hnsfrmActivity = new HNSFitnessActivity(hnsUser.userid,hnsUser.Lastusername);
            hnsfrmActivity.ShowDialog();

        }

        private void Close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (ShowPassword.Checked== false)
            {
                Password.UseSystemPasswordChar = false;
            }
            else
            {
                Password.UseSystemPasswordChar = true;
            }
        }

        private void HNSfrmRegister_Load(object sender, EventArgs e)
        {

        }

        private void PhNobtn_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
