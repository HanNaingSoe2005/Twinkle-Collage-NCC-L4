﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FitnessApplication
{
    public class ClassBasketball: ClassHnsActivity
    {
        public float BasketballActivity(int uid, float m1, float m2, float m3)
        {

            float cal = m1 * m2 * m3;

            return cal/1000;
        }
    }
}
